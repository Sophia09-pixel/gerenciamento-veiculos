﻿using Dapper;
using Domain;
using Microsoft.AspNetCore.Mvc;
using MySqlConnector;
using Newtonsoft.Json;
using Repository;
using StackExchange.Redis;

namespace VehicleApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class VehicleController : ControllerBase
    {
        private const string key = "get-vehicles";
        private const string redisConnection = "localhost:6379";
        private readonly IVehicleRepository vehicleRepository;

        public VehicleController(IVehicleRepository vehicleRepository)
        {
            //recebe a injeção de dependencia
            this.vehicleRepository = vehicleRepository;
        }


        [HttpGet]
        public async Task<IActionResult> Get()
        {
            //Implementar o cache
            var redis = ConnectionMultiplexer.Connect(redisConnection);
            IDatabase db = redis.GetDatabase();
            await db.KeyExpireAsync(key, TimeSpan.FromMinutes(20)); // colocando 20 minutos no cache
            string vehiclesValue = await db.StringGetAsync(key); // verificar se há chache

            if (!string.IsNullOrEmpty(vehiclesValue))
            {
                return Ok(vehiclesValue);
            }

            var vehicles = await vehicleRepository.GetAllVehiclesAsync();
            var vehiclesJson = JsonConvert.SerializeObject(vehicles);
            await db.StringSetAsync(key, vehiclesJson); // salvando no cache
            Thread.Sleep(3000); //forçando uma espera
            return Ok(vehicles);
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromBody] Vehicle vehicles)
        {
            if (vehicles == null)
            {
                return BadRequest("Dados inválidos");
            }

            using var connection = new MySqlConnection(connectionString);
            await connection.OpenAsync();

            string sql = @"
                insert into vehicles(brand, model, year, plate) 
                values(@Brand, @Model, @Year, @Plate); 
                select last_insert_id();
            ";

            var newId = await connection.QuerySingleAsync<int>(sql, vehicles);
            vehicles.Id = newId;

            //Invalidar cache
            await InvalidateCache();

            return CreatedAtAction(nameof(Get), new { id = newId }, vehicles);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Put(int id, [FromBody] Vehicle vehicles)
        {
            if (vehicles == null)
            {
                return BadRequest("Usuário inválido");
            }

            using var connection = new MySqlConnection(connectionString);
            await connection.OpenAsync();

            string sql = @"
                update vehicles set brand = @Brand, model = @Model, year = @Year, plate = @Plate where id = @Id
            ";

            vehicles.Id = id;
            var rowsAffected = await connection.ExecuteAsync(sql, vehicles);

            if (rowsAffected == 0)
            {
                return NotFound("Nenhum usuário encontrado");
            }

            //Invalidar cache
            await InvalidateCache();

            return NoContent();

        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            if (id == 0)
            {
                return BadRequest("Identificador não informado");
            }

            using var connection = new MySqlConnection(connectionString);
            await connection.OpenAsync();

            var sql = "delete from vehicles where id = @id";

            var rowsAffected = await connection.ExecuteAsync(sql, new { id });

            if (rowsAffected == 0)
            {
                return NotFound("Nenhum usuário encontrado");
            }
            //Invalidar cache
            await InvalidateCache();

            return NoContent();
        }

        //Invalidar cache
        private async Task InvalidateCache()
        {
            var redis = ConnectionMultiplexer.Connect(redisConnection);
            IDatabase db = redis.GetDatabase();
            await db.KeyDeleteAsync(key);
        }
    }
}
