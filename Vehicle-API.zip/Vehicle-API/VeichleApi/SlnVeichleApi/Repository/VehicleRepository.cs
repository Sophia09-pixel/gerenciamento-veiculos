﻿using Dapper;
using Domain;
using Microsoft.Extensions.Configuration;
using MySqlConnector;

namespace Repository
{
    public class VehicleRepository : IVehicleRepository
    {
        private readonly string _connectionString;

        public VehicleRepository(IConfiguration configuration)
        {
            _connectionString = configuration["DefaultConnection"];
        }

        public async Task<IEnumerable<Vehicle>> GetAllVehiclesAsync()
        {
            using var connection = new MySqlConnection(_connectionString);
            await connection.OpenAsync();
            var sql = "select id, brand, model, year, plate, color from vehicles; ";
            return await connection.QueryAsync<Vehicle>(sql);
        }

        public async Task<Vehicle> AddVehicleAsync(Vehicle vehicle)
        {
            using var connection = new MySqlConnection(_connectionString);
            await connection.OpenAsync();

            string sql = @"
                INSERT INTO vehicle (brand, model, year, plate, color)
                VALUES (@Brand, @Model, @Year, @Plate, @Color);
                SELECT LAST_INSERT_ID();
            ";

            int newId = await connection.QuerySingleAsync<int>(sql, vehicle);
            vehicle.Id = newId;
            return vehicle;
        }

        public async Task UpdateVehicleAsync(Vehicle vehicle)
        {
            using var connection = new MySqlConnection(_connectionString);
            await connection.OpenAsync();

            string sql = @"
                UPDATE vehicle
                SET brand = @Brand, model = @Model, year = @Year, 
                    plate = @Plate, color = @Color
                WHERE id = @Id;
            ";

            await connection.ExecuteAsync(sql, vehicle);
        }

        public async Task DeleteVehicleAsync(int id)
        {
            using var connection = new MySqlConnection(_connectionString);
            await connection.OpenAsync();

            string sql = "DELETE FROM vehicle WHERE id = @Id;";
            await connection.ExecuteAsync(sql, new { Id = id });
        }
    }
}